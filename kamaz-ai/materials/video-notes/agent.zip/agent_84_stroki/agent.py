"""Минимальный ИИ-агент: модель + инструменты + цикл.

Мозг — любая модель с API в формате OpenAI: локальный llama-server, Ollama или облако.
    python agent.py "Какая у меня видеокарта?"
"""
import json
import subprocess
import sys

import requests

URL = "http://127.0.0.1:8080/v1/chat/completions"  # облако: поменять адрес, ключ и модель
KEY = "local"
MODEL = "local"

TOOLS = [
    {"type": "function", "function": {
        "name": "run_command",
        "description": "Выполнить команду PowerShell на компьютере пользователя и вернуть её вывод.",
        "parameters": {"type": "object", "required": ["command"],
                       "properties": {"command": {"type": "string", "description": "команда PowerShell"}}}}},
    {"type": "function", "function": {
        "name": "write_file",
        "description": "Записать текст в файл (UTF-8). Если файл уже есть, он будет перезаписан.",
        "parameters": {"type": "object", "required": ["path", "content"],
                       "properties": {"path": {"type": "string"}, "content": {"type": "string"}}}}},
]


def allowed(action):
    """Человек в цикле: без «y» ничего не происходит."""
    return input(f"   Агент хочет {action}. Разрешить? [y/n] ").strip().lower() == "y"


def run_command(command):
    if not allowed(f"выполнить: {command}"):
        return "Пользователь запретил эту команду."
    utf8 = "[Console]::OutputEncoding = [Text.Encoding]::UTF8; "
    r = subprocess.run(["powershell", "-NoProfile", "-Command", utf8 + command],
                       capture_output=True, encoding="utf-8", errors="replace", timeout=120)
    return ((r.stdout or "") + (r.stderr or ""))[-4000:] or "(команда ничего не вывела)"


def write_file(path, content):
    if not allowed(f"записать файл {path}"):
        return "Пользователь запретил запись."
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return f"Готово: {len(content)} символов в {path}"


FUNCS = {"run_command": run_command, "write_file": write_file}
SYSTEM = ("Ты агент на компьютере пользователя с Windows. Решай задачу по шагам с помощью инструментов "
          "и проверяй результаты. Когда всё сделано, коротко скажи, что получилось.")


def agent(task, max_steps=15):
    messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": task}]
    for step in range(1, max_steps + 1):
        reply = requests.post(URL, headers={"Authorization": f"Bearer {KEY}"}, timeout=600,
                              json={"model": MODEL, "messages": messages, "tools": TOOLS}).json()
        msg = reply["choices"][0]["message"]
        calls = msg.get("tool_calls") or []
        if msg.get("reasoning_content"):
            print(f"[{step}] мысль: {msg['reasoning_content'].strip()[:200]}")
        messages.append({"role": "assistant", "content": msg.get("content") or "",
                         **({"tool_calls": calls} if calls else {})})
        if not calls:  # инструменты больше не нужны — это ответ
            return msg.get("content")
        for call in calls:
            name = call["function"]["name"]
            print(f"[{step}] действие: {name} {call['function']['arguments']}")
            try:
                args = json.loads(call["function"]["arguments"] or "{}")
                result = FUNCS[name](**args)
            except Exception as e:  # ошибка — тоже наблюдение: модель увидит её и исправится
                result = f"Ошибка: {e!r}"
            print(f"[{step}] результат: {result[:300]}")
            messages.append({"role": "tool", "tool_call_id": call.get("id", str(step)), "content": result})
    return "Стоп: закончился лимит шагов."


if __name__ == "__main__":
    print("\nОтвет:", agent(" ".join(sys.argv[1:]) or input("Задача: ")))
